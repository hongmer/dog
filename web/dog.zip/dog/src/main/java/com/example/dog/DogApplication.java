package com.example.dog;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = {"com.example.dog.service","com.example.dog.mapper","com.example.dog.entity","com.example.dog.controller"})
@MapperScan("com.example.dog.mapper")
@SpringBootApplication
public class DogApplication {

    public static void main(String[] args) {
        SpringApplication.run(DogApplication.class, args);
    }

}
