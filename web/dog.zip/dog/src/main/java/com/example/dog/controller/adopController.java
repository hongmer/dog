package com.example.dog.controller;


import com.example.dog.entity.adop;
import com.example.dog.service.adopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(value ="/try")
public class adopController {

    @Autowired
    private adopService adopService;

    @GetMapping(value = "/adopbyid")
    public adop AdopByPrimaryKey(HttpServletRequest request) {
        Integer id = Integer.parseInt(request.getParameter("id"));
        System.out.println(id);
        System.out.println(adopService.selectByPrimaryKey(id));
        return adopService.selectByPrimaryKey(id);
    }
    @RequestMapping(value = "/select")
    public adop[] select(){
        return adopService.select();
    }
}
