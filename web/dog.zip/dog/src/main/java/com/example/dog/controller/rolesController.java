package com.example.dog.controller;

import com.example.dog.entity.roles;
import com.example.dog.service.rolesService;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;


@RestController
@RequestMapping(value ="/try")
public class rolesController {

    @Autowired
    private rolesService rolesService;


    @GetMapping(value = "/rolesinseret")
    public void RolesInsert(HttpServletRequest request) {
        Integer id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("rolesname");
        System.out.println(id);
        System.out.println(name);
        System.out.println(rolesService.insert(id,name));

    }

    @RequestMapping(value = "/springboot")
    public void hello(){
        System.out.println("hello");
    }
}
