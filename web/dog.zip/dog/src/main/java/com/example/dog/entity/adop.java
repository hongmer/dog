package com.example.dog.entity;

import java.util.Date;

public class adop {
    private Integer petsId;

    private String petsName;

    private String petsKind;

    private String petsSpecies;

    private String petsAddress;

    private String petsAdopcondition;

    private String petsDescribe;

    private String petsLinkman;

    private String petsLmwechat;

    private String petsLmphone;

    private Integer senderId;

    private Date sendTime;

    private String petsImg;

    private Integer ismoney;

    public Integer getPetsId() {
        return petsId;
    }

    public void setPetsId(Integer petsId) {
        this.petsId = petsId;
    }

    public String getPetsName() {
        return petsName;
    }

    public void setPetsName(String petsName) {
        this.petsName = petsName == null ? null : petsName.trim();
    }

    public String getPetsKind() {
        return petsKind;
    }

    public void setPetsKind(String petsKind) {
        this.petsKind = petsKind == null ? null : petsKind.trim();
    }

    public String getPetsSpecies() {
        return petsSpecies;
    }

    public void setPetsSpecies(String petsSpecies) {
        this.petsSpecies = petsSpecies == null ? null : petsSpecies.trim();
    }

    public String getPetsAddress() {
        return petsAddress;
    }

    public void setPetsAddress(String petsAddress) {
        this.petsAddress = petsAddress == null ? null : petsAddress.trim();
    }

    public String getPetsAdopcondition() {
        return petsAdopcondition;
    }

    public void setPetsAdopcondition(String petsAdopcondition) {
        this.petsAdopcondition = petsAdopcondition == null ? null : petsAdopcondition.trim();
    }

    public String getPetsDescribe() {
        return petsDescribe;
    }

    public void setPetsDescribe(String petsDescribe) {
        this.petsDescribe = petsDescribe == null ? null : petsDescribe.trim();
    }

    public String getPetsLinkman() {
        return petsLinkman;
    }

    public void setPetsLinkman(String petsLinkman) {
        this.petsLinkman = petsLinkman == null ? null : petsLinkman.trim();
    }

    public String getPetsLmwechat() {
        return petsLmwechat;
    }

    public void setPetsLmwechat(String petsLmwechat) {
        this.petsLmwechat = petsLmwechat == null ? null : petsLmwechat.trim();
    }

    public String getPetsLmphone() {
        return petsLmphone;
    }

    public void setPetsLmphone(String petsLmphone) {
        this.petsLmphone = petsLmphone == null ? null : petsLmphone.trim();
    }

    public Integer getSenderId() {
        return senderId;
    }

    public void setSenderId(Integer senderId) {
        this.senderId = senderId;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getPetsImg() {
        return petsImg;
    }

    public void setPetsImg(String petsImg) {
        this.petsImg = petsImg == null ? null : petsImg.trim();
    }

    public Integer getIsmoney() {
        return ismoney;
    }

    public void setIsmoney(Integer ismoney) {
        this.ismoney = ismoney;
    }
}