package com.example.dog.entity;

import java.util.Date;

public class messages {
    private Integer mesId;

    private Integer mesSender;

    private Integer mesReceiver;

    private String mesDescribe;

    private Date mesTime;

    private Integer mesStates;

    public Integer getMesId() {
        return mesId;
    }

    public void setMesId(Integer mesId) {
        this.mesId = mesId;
    }

    public Integer getMesSender() {
        return mesSender;
    }

    public void setMesSender(Integer mesSender) {
        this.mesSender = mesSender;
    }

    public Integer getMesReceiver() {
        return mesReceiver;
    }

    public void setMesReceiver(Integer mesReceiver) {
        this.mesReceiver = mesReceiver;
    }

    public String getMesDescribe() {
        return mesDescribe;
    }

    public void setMesDescribe(String mesDescribe) {
        this.mesDescribe = mesDescribe == null ? null : mesDescribe.trim();
    }

    public Date getMesTime() {
        return mesTime;
    }

    public void setMesTime(Date mesTime) {
        this.mesTime = mesTime;
    }

    public Integer getMesStates() {
        return mesStates;
    }

    public void setMesStates(Integer mesStates) {
        this.mesStates = mesStates;
    }
}