package com.example.dog.entity;

import java.util.Date;

public class save {
    private Integer saveId;

    private String saveLinkman;

    private String saveLmphone;

    private String saveAddress;

    private String saveDescribe;

    private Integer senderId;

    private Integer reciverId;

    private Integer saveState;

    private Date saveTime;

    private String saveImg;

    public Integer getSaveId() {
        return saveId;
    }

    public void setSaveId(Integer saveId) {
        this.saveId = saveId;
    }

    public String getSaveLinkman() {
        return saveLinkman;
    }

    public void setSaveLinkman(String saveLinkman) {
        this.saveLinkman = saveLinkman == null ? null : saveLinkman.trim();
    }

    public String getSaveLmphone() {
        return saveLmphone;
    }

    public void setSaveLmphone(String saveLmphone) {
        this.saveLmphone = saveLmphone == null ? null : saveLmphone.trim();
    }

    public String getSaveAddress() {
        return saveAddress;
    }

    public void setSaveAddress(String saveAddress) {
        this.saveAddress = saveAddress == null ? null : saveAddress.trim();
    }

    public String getSaveDescribe() {
        return saveDescribe;
    }

    public void setSaveDescribe(String saveDescribe) {
        this.saveDescribe = saveDescribe == null ? null : saveDescribe.trim();
    }

    public Integer getSenderId() {
        return senderId;
    }

    public void setSenderId(Integer senderId) {
        this.senderId = senderId;
    }

    public Integer getReciverId() {
        return reciverId;
    }

    public void setReciverId(Integer reciverId) {
        this.reciverId = reciverId;
    }

    public Integer getSaveState() {
        return saveState;
    }

    public void setSaveState(Integer saveState) {
        this.saveState = saveState;
    }

    public Date getSaveTime() {
        return saveTime;
    }

    public void setSaveTime(Date saveTime) {
        this.saveTime = saveTime;
    }

    public String getSaveImg() {
        return saveImg;
    }

    public void setSaveImg(String saveImg) {
        this.saveImg = saveImg == null ? null : saveImg.trim();
    }
}