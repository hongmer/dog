package com.example.dog.entity;

public class states {
    private Integer statesId;

    private String statesDescribe;

    public Integer getStatesId() {
        return statesId;
    }

    public void setStatesId(Integer statesId) {
        this.statesId = statesId;
    }

    public String getStatesDescribe() {
        return statesDescribe;
    }

    public void setStatesDescribe(String statesDescribe) {
        this.statesDescribe = statesDescribe == null ? null : statesDescribe.trim();
    }
}