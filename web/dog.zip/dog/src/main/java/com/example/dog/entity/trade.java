package com.example.dog.entity;

import java.util.Date;

public class trade {
    private Integer tradeId;

    private Integer petsId;

    private Integer tradeApplyman;

    private Integer tradeRespondman;

    private Integer tradeStates;

    private Date tradeTime;

    public Integer getTradeId() {
        return tradeId;
    }

    public void setTradeId(Integer tradeId) {
        this.tradeId = tradeId;
    }

    public Integer getPetsId() {
        return petsId;
    }

    public void setPetsId(Integer petsId) {
        this.petsId = petsId;
    }

    public Integer getTradeApplyman() {
        return tradeApplyman;
    }

    public void setTradeApplyman(Integer tradeApplyman) {
        this.tradeApplyman = tradeApplyman;
    }

    public Integer getTradeRespondman() {
        return tradeRespondman;
    }

    public void setTradeRespondman(Integer tradeRespondman) {
        this.tradeRespondman = tradeRespondman;
    }

    public Integer getTradeStates() {
        return tradeStates;
    }

    public void setTradeStates(Integer tradeStates) {
        this.tradeStates = tradeStates;
    }

    public Date getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(Date tradeTime) {
        this.tradeTime = tradeTime;
    }
}