package com.example.dog.entity;

public class users {
    private Integer usersId;

    private String usersName;

    private String usersPassword;

    private String usersAddress;

    private String usersPhone;

    private Integer usersRole;

    private String usersImg;

    public Integer getUsersId() {
        return usersId;
    }

    public void setUsersId(Integer usersId) {
        this.usersId = usersId;
    }

    public String getUsersName() {
        return usersName;
    }

    public void setUsersName(String usersName) {
        this.usersName = usersName == null ? null : usersName.trim();
    }

    public String getUsersPassword() {
        return usersPassword;
    }

    public void setUsersPassword(String usersPassword) {
        this.usersPassword = usersPassword == null ? null : usersPassword.trim();
    }

    public String getUsersAddress() {
        return usersAddress;
    }

    public void setUsersAddress(String usersAddress) {
        this.usersAddress = usersAddress == null ? null : usersAddress.trim();
    }

    public String getUsersPhone() {
        return usersPhone;
    }

    public void setUsersPhone(String usersPhone) {
        this.usersPhone = usersPhone == null ? null : usersPhone.trim();
    }

    public Integer getUsersRole() {
        return usersRole;
    }

    public void setUsersRole(Integer usersRole) {
        this.usersRole = usersRole;
    }

    public String getUsersImg() {
        return usersImg;
    }

    public void setUsersImg(String usersImg) {
        this.usersImg = usersImg == null ? null : usersImg.trim();
    }
}