package com.example.dog.mapper;

import com.example.dog.entity.adop;

public interface adopMapper {
    int deleteByPrimaryKey(Integer petsId);

    int insert(adop record);

    int insertSelective(adop record);

    adop selectByPrimaryKey(Integer petsId);

    adop[] select();

    int updateByPrimaryKeySelective(adop record);

    int updateByPrimaryKey(adop record);
}