package com.example.dog.mapper;

import com.example.dog.entity.messages;

public interface messagesMapper {
    int deleteByPrimaryKey(Integer mesId);

    int insert(messages record);

    int insertSelective(messages record);

    messages selectByPrimaryKey(Integer mesId);

    int updateByPrimaryKeySelective(messages record);

    int updateByPrimaryKey(messages record);
}