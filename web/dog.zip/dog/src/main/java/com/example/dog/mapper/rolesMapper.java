package com.example.dog.mapper;

import com.example.dog.entity.roles;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface rolesMapper {
    int insert(@Param("rolesId")Integer id , @Param("rolesName")String name);
    int insertSelective(roles record);
}