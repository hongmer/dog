package com.example.dog.mapper;

import com.example.dog.entity.save;

public interface saveMapper {
    int deleteByPrimaryKey(Integer saveId);

    int insert(save record);

    int insertSelective(save record);

    save selectByPrimaryKey(Integer saveId);

    int updateByPrimaryKeySelective(save record);

    int updateByPrimaryKey(save record);
}