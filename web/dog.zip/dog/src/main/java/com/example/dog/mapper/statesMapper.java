package com.example.dog.mapper;

import com.example.dog.entity.states;

public interface statesMapper {
    int insert(states record);

    int insertSelective(states record);
}