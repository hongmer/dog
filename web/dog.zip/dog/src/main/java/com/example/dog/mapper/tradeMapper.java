package com.example.dog.mapper;

import com.example.dog.entity.trade;

public interface tradeMapper {
    int deleteByPrimaryKey(Integer tradeId);

    int insert(trade record);

    int insertSelective(trade record);

    trade selectByPrimaryKey(Integer tradeId);

    int updateByPrimaryKeySelective(trade record);

    int updateByPrimaryKey(trade record);
}