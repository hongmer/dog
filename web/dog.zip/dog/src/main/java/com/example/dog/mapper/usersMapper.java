package com.example.dog.mapper;

import com.example.dog.entity.users;

public interface usersMapper {
    int deleteByPrimaryKey(Integer usersId);

    int insert(users record);

    int insertSelective(users record);

    users selectByPrimaryKey(Integer usersId);

    int updateByPrimaryKeySelective(users record);

    int updateByPrimaryKey(users record);
}