package com.example.dog.service;

import com.example.dog.entity.adop;
import com.example.dog.mapper.adopMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class adopService {
    @Autowired
    private adopMapper adopMapper;

    public adop[] select(){
        return adopMapper.select();
    }

    public adop selectByPrimaryKey(Integer id){
        return adopMapper.selectByPrimaryKey(id);
    }
}
