package com.example.dog.service;

import com.example.dog.entity.roles;
import com.example.dog.mapper.rolesMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class rolesService {

    @Autowired
    private rolesMapper rolesMapper;

    public int insert(Integer id , String name){
        return rolesMapper.insert(id , name);
    }
}
